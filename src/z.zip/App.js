import './App.css';

const App = (props) => props.children;

export default App;
