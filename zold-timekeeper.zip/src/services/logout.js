const logout = () => {
    localStorage.removeItem('token');
    //will redirect to landing page
}